package Encapsulamento;

public class Conta {
    private double saldo;

    void deposita(double valor) {
        this.saldo += valor;
        this.descontaTarifa();
    }
    void saca(double valor) {
        this.saldo -= valor;
        this.descontaTarifa();
    }
    private void descontaTarifa() {
        this.saldo -= 0.1;
    }
}
