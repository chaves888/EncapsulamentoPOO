package Encapsulamento;

public class Programa {
    public static void main(String[] args) {
        var Vehicle = new Vehicle();
        var Conta = new Conta();

        Vehicle.setColor("#FFFFFF");
        Conta.deposita(1000);
    }
}
